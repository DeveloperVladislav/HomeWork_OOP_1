﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HomeWork_OOP_1
{
	public enum AnimalGroup
	{
		Mammals,     //млекопитающие
		Reptiles,    //рептилии
		Amphibians,  //земноводные
		Birds,       //птицыы
		Insects,     //насекомые
		Fish         //рыбы
	}
	public class Animal//поставим sealed и всем наследникам хана...
	{
		protected internal AnimalGroup NameType { get; set; } //доступ только внутри сборки и у его наследников в любой сборке
		private protected int Age { get; set; } //Доступно внутри класса Animal и его наследникам в этой же сборке

		public Animal()
		{
		}
		public Animal(AnimalGroup nameType,int age)
		{
			NameType = nameType;
			Age = age;
		}

		protected internal void Print(string name) //Доступно внутри сборки и наследникам в любой сборке
		{
			Console.WriteLine($"This is {NameType}\nName: {name}");
		}
	}
}
